function learnFacts(note, context){
    addAction({
        type: "learn_facts",
        note: note
    }, context);
}

function closeModalWindow(note, context){
    addAction({
        type: "close_modal_window",
        note: note
    }, context);
}

function сhooseTheme(id, context){
    addAction({
        type: 'choose_theme',
        id: id
    }, context);
}

function returnMenu(note, context){
    addAction({
        type: 'return_menu',
        note: note
    }, context);
}

function attemptToQuiz(note, context){
    addAction({
        type: 'attemptToQuiz',
        note: note
    }, context);
}

function closeModalForQuiz(note, context){
    addAction({
        type: 'closeModalForQuiz',
        note: note
    }, context)
}

function Answer(id, context){
    addAction({
        type: 'Answer',
        id: id
    }, context)
}

function Next(note, context){
    addAction({
        type: 'Next',
        note: note
    }, context)
}

function Menu(note, context){
    addAction({
        type: 'MenuAfterGame',
        note: note
    }, context)
}

function ScaleFacts(id, context){
    addAction({
        type: "ScaleFact",
        id: id
    }, context)
}

function CloseModalFact(id, context){
    addAction({
        type: "CloseModalFact",
        id: id
    }, context)
}

function showResults(note, context){
    addAction({
        type: "showRes",
        note: note
    }, context)
}